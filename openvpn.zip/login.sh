#!/bin/bash
##
## Debian VPN Authentication Script
## by JohnFordTV
##
## Copyright (c) Debian VPN 2019. All Rights Reserved
##

user_id=$(mysql -hDBhost -P3306 -uDBuser -pDBpass DBname -sN -e "SELECT user_name FROM users WHERE user_name = '$username' AND user_pass = '$password' AND user_server = 'ServerPrefix'")
[ "$user_id" != '' ] && [ "$user_id" = "$username" ] && echo 'authentication ok.' && exit 0 || echo 'authentication failed.'; exit 1
